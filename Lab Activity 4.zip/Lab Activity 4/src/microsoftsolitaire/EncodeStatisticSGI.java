package microsoftsolitaire;

import java.io.*;
import java.util.Scanner;

public class EncodeStatisticSGI {
    public static void main(String[] args) {
        File source = new File("res/statistics (hexadecimal).txt");
        File destination = new File("res/STATISTIC (ORIGINAL).sgi");
        try (
                Scanner textInput = new Scanner(source);
                DataOutputStream binaryOutput = new DataOutputStream(new FileOutputStream(destination));
        ) {
            String hexadecimalString;

            textInput.nextLine(); // skip the first line header
            while (textInput.hasNext()) {
                // read each text ...
                hexadecimalString = textInput.next();
                try {
                    // ... and write it binary (as a byte value)
                    binaryOutput.writeByte(Integer.parseInt(hexadecimalString, 16));
                    binaryOutput.flush();
                } catch(NumberFormatException nfe) {
                    // do nothing
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
