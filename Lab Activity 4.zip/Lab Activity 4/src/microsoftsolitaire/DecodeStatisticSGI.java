package microsoftsolitaire;

import java.io.*;

/**
 * INPUT: statistic (original).sgi
 * OUTPUT: statistics (hexadeimal).txt -- text representation of the .sgi file in hexadecimal string format, e.g. String.format("%02X", ...)
 */
public class DecodeStatisticSGI {
    public static void main(String[] args) {
        File source = new File("res/statistic (original).sgi");
        File destination = new File("res/statistics (hexadecimal).txt");

        try (
                DataInputStream binaryInput = new DataInputStream(new FileInputStream(source));
                PrintWriter textOutput = new PrintWriter(destination);
        ) {
            long fileSize = source.length();
            byte data;

            // print the text header
            textOutput.print("     0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F");

            for (int i = 0; i < fileSize; i++) {
                // read a byte ...
                data = binaryInput.readByte();
                if (i % 16 == 0) {
                    // ... and write it as a hexadecimal string
                    textOutput.printf("%n%02X:", i / 16);
                }
                textOutput.print(String.format(" %02X", data));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println();

    }

}
